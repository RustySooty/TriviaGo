package com.example.triviaapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SignupActivity extends AppCompatActivity {
    EditText emailEditText;
    EditText passwordEditText;
    EditText confirmPasswordEditText;
    Button btnSignUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);

        emailEditText = findViewById(R.id.etEmailAddress);
        passwordEditText = findViewById(R.id.etPassword);
        confirmPasswordEditText = findViewById(R.id.etConfirmPassword);
        btnSignUp = findViewById(R.id.btnSignUp);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void btnSignUpHandler(View view) {
        // Get user input
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();

        // Validate input (e.g., check for empty fields)
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
            Toast.makeText(SignupActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            Toast.makeText(SignupActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Perform sign-up process
        signUp(email, password);
    }

    public void btnGoLoginHandler(View view) {
        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
        startActivity(intent);
        finish(); // Optional: Finish the current activity to prevent users from going back to the login screen using the back button
    }
    private void signUp(String email, String password) {
        // Send sign-up information to server-side for registration
        // You can use AsyncTask, Volley, Retrofit, or any other networking library to make HTTP requests
        // Here, we'll use AsyncTask for simplicity
        new SignUpAsyncTask().execute(email, password);
    }
    /** TEST SIGN UP PROCESS */
    private class SignUpAsyncTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            // Simulate successful registration
            return true;
        }

        @Override
        protected void onPostExecute(Boolean registrationSuccess) {
            if (registrationSuccess) {
                Toast.makeText(SignupActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                // Proceed to another screen/activity if needed
                Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity to prevent users from going back to the login screen using the back button

            } else {
                Toast.makeText(SignupActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }
/**    SIGNUP PROCESS WITH WEB AUTHENTICATION */
//    private class SignUpAsyncTask extends AsyncTask<String, Void, Boolean> {
//        @Override
//        protected Boolean doInBackground(String... params) {
//            // Retrieve sign-up information
//            String email = params[0];
//            String password = params[1];
//
//            // Your server URL for registration
//            String serverUrl = "http://yourserver.com/signup.php";
//
//            try {
//                URL url = new URL(serverUrl);
//                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//                connection.setRequestMethod("POST");
//                connection.setDoOutput(true);
//
//                // Send data
//                String postData = "email=" + email + "&password=" + password;
//                OutputStream outputStream = connection.getOutputStream();
//                outputStream.write(postData.getBytes());
//                outputStream.flush();
//                outputStream.close();
//
//                int responseCode = connection.getResponseCode();
//                return responseCode == HttpURLConnection.HTTP_OK;
//            } catch (IOException e) {
//                e.printStackTrace();
//                return false;
//            }
//        }
//
//        @Override
//        protected void onPostExecute(Boolean registrationSuccess) {
//            if (registrationSuccess) {
//                // Registration successful
//                Toast.makeText(SignupActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
//                // Proceed to another screen/activity if needed
//                Intent intent = new Intent(SignupActivity.this, MainActivity.class);
//                startActivity(intent);
//                finish(); // Optional: Finish the current activity to prevent users from going back to the login screen using the back button
//
//            } else {
//                // Registration failed
//                Toast.makeText(SignupActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
}