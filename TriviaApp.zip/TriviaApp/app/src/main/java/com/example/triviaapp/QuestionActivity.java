package com.example.triviaapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class QuestionActivity extends AppCompatActivity {

    Button btnA, btnB, btnC, btnD;
    private TextView questionNumTextView;
    private TextView questionTextView;
    private String selectedOption;
    private int currentQuestionIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_question);

        btnA = findViewById(R.id.ans_A);
        btnB = findViewById(R.id.ans_B);
        btnC = findViewById(R.id.ans_C);
        btnD = findViewById(R.id.ans_D);

        questionNumTextView = findViewById(R.id.questionNum);
        questionTextView = findViewById(R.id.question);

        currentQuestionIndex = 1;
        updateQuestionAndNumber("Which website is IEM students' favourite?", currentQuestionIndex);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    // Handle click event for option A button
    public void btnAHandler(View view) {
        handleOptionButtonClick("A");
    }

    // Handle click event for option B button
    public void btnBHandler(View view) {
        handleOptionButtonClick("B");
    }

    // Handle click event for option C button
    public void btnCHandler(View view) {
        handleOptionButtonClick("C");
    }

    // Handle click event for option D button
    public void btnDHandler(View view) {
        handleOptionButtonClick("D");
    }

    private void handleOptionButtonClick(String option) {
        selectedOption = option;

        // Simulate sending selected option to the web portion and request for the next question
        new NextQuestionAsyncTask().execute(selectedOption);
    }
    private void updateQuestionAndNumber(String question, int questionIndex) {
        // Cap the question index at 10
        if (questionIndex > 10) {
            questionIndex = 10;
        }
        // Update question text
        questionTextView.setText(question);

        // Update question number
        questionNumTextView.setText(getString(R.string.question_number_format, questionIndex, getTotalQuestions()));
    }

    private int getTotalQuestions() {
        // Return the total number of questions (you can replace this with your actual number of questions)
        return 10;
    }

/** TEST QUESTION PROCESS  */
//    private class NextQuestionAsyncTask extends AsyncTask<String, Void, String> {
//        @Override
//        protected String doInBackground(String... selectedOption) {
//            // Simulate sending selected option to the web portion and request for the next question
//            // Here you can perform network operations to send the selected option to the web
//            // You can also receive the next question from the web
//            // For simplicity, let's return a hardcoded next question
//            return "What is the capital of Malaysia?";
//        }
//
//        @Override
//        protected void onPostExecute(String nextQuestion) {
//            // Display the next question
//            currentQuestionIndex++;
//            updateQuestionAndNumber(nextQuestion, currentQuestionIndex);
//            // Inform the user that the next question is displayed
//            Toast.makeText(QuestionActivity.this, "Next question displayed", Toast.LENGTH_SHORT).show();
//        }
//    }

    /** QUESTION PROCESS WITH WEB AUTHENTICATION */
    public class NextQuestionAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... selectedOption) {
            String choice = selectedOption[0];
            String urlString = "http://ip_addr:port/clicker/select?choice=" + choice;

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String nextQuestion = null;

            try {
                URL url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");

                // Read the response from the server
                InputStream inputStream = urlConnection.getInputStream();
                StringBuilder stringBuilder = new StringBuilder();
                if (inputStream != null) {
                    reader = new BufferedReader(new InputStreamReader(inputStream));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    nextQuestion = stringBuilder.toString();
                }
            } catch (IOException e) {
                Log.e("NextQuestionAsyncTask", "Error fetching data", e);
            } finally {
                // Close the connection and the reader
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        Log.e("NextQuestionAsyncTask", "Error closing reader", e);
                    }
                }
            }

            return nextQuestion;
        }

        @Override
        protected void onPostExecute(String nextQuestion) {
            if (nextQuestion != null) {
                // Display the next question
                currentQuestionIndex++;
                updateQuestionAndNumber(nextQuestion, currentQuestionIndex);
                // Inform the user that the next question is displayed
                Toast.makeText(QuestionActivity.this, "Next question displayed", Toast.LENGTH_SHORT).show();
            } else {
                // Handle the case where next question is null or fetching failed
                Toast.makeText(QuestionActivity.this, "Failed to fetch next question", Toast.LENGTH_SHORT).show();
            }
        }
    }
}