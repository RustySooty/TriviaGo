package com.example.triviaapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Button   btnLogin;
    EditText emailEditText;
    EditText passwordEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        btnLogin     = (Button) findViewById(R.id.btnLogin);
        emailEditText = findViewById(R.id.etEmailAddress);
        passwordEditText = findViewById(R.id.etPassword);

//        btnLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String email = emailEditText.getText().toString();
//                String password = passwordEditText.getText().toString();
//
//                // Perform login process
//                new LoginAsyncTask().execute(email, password);
//            }
//        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void btnLoginHandler(View view) {
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Perform login process
        new LoginAsyncTask().execute(email, password);
    }

    public void btnGoSignUpHandler(View view) {
        Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
        startActivity(intent);
        finish(); // Optional: Finish the current activity to prevent users from going back to the login screen using the back button
    }

//    EH CHUA CODES
//    public void btnLoginHandler (View v) {
//        btnLogin.setEnabled(false);  // Disable the button
//        new HttpTask().execute("https://www.ntu.edu.sg"); // Send HTTP request
//        //new HttpTask().execute("https://www.android.com"); // Send HTTP request
//        //new HttpTask().execute("http://ip_addr:port/hello");
//        //new HttpTask().execute("http://10.0.2.2:9999/hello");  // Tomcat at localhost:9999
//        Toast.makeText(this, "Send", Toast.LENGTH_LONG).show(); // Toast a message
//    }

    /** TEST LOGIN PROCESS */
    private class LoginAsyncTask extends AsyncTask<String, Void, Boolean> {
        @Override
        protected Boolean doInBackground(String... params) {
            // Simulate successful login
            String email = params[0];
            String password = params[1];

            // Hardcoded email and password for testing
            String hardcodedEmail = "test@example.com";
            String hardcodedPassword = "password";

            // Log the entered email and password
            Log.d("LoginDebug", "Entered Email: " + email);
            Log.d("LoginDebug", "Entered Password: " + password);

            // Log the hardcoded email and password
            Log.d("LoginDebug", "Hardcoded Email: " + hardcodedEmail);
            Log.d("LoginDebug", "Hardcoded Password: " + hardcodedPassword);

            // Check if the entered email and password match the hardcoded values
            boolean loginSuccess = email.equals(hardcodedEmail) && password.equals(hardcodedPassword);

            // Log the login success status
            Log.d("LoginDebug", "Login Success: " + loginSuccess);

            return loginSuccess;
        }

        @Override
        protected void onPostExecute(Boolean loginSuccess) {
            if (!loginSuccess) {
                // Simulated login failed
                Toast.makeText(LoginActivity.this, "Login failed. Please try again.", Toast.LENGTH_SHORT).show();
            } else {
                // Simulated login successful
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                // Proceed to the next screen/activity
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional: Finish the current activity to prevent users from going back to the login screen using the back button
            }
        }
    }

/**    LOGIN PROCESS WITH WEB AUTHENTICATION */
//    private class LoginAsyncTask extends AsyncTask<String, Void, String> {
//        @Override
//        protected String doInBackground(String... params) {
//            String email = params[0];
//            String password = params[1];
//
//            // Send HTTP request to server-side script
//            // Replace SERVER_URL with the actual URL of the server-side script
//            String serverUrl = "http://example.com/login.php";
//            String response = "";
//
//            try {
//                URL url = new URL(serverUrl);
//                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
//                urlConnection.setRequestMethod("POST");
//                urlConnection.setDoOutput(true);
//
//                // Send email and password as POST parameters
//                OutputStream outputStream = urlConnection.getOutputStream();
//                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
//                String postData = "email=" + URLEncoder.encode(email, "UTF-8") +
//                        "&password=" + URLEncoder.encode(password, "UTF-8");
//                writer.write(postData);
//                writer.flush();
//                writer.close();
//                outputStream.close();
//
//                // Read response from server
//                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
//                String line;
//                StringBuilder stringBuilder = new StringBuilder();
//                while ((line = reader.readLine()) != null) {
//                    stringBuilder.append(line).append("\n");
//                }
//                response = stringBuilder.toString();
//                reader.close();
//
//                // Disconnect HttpURLConnection
//                urlConnection.disconnect();
//            } catch (IOException e) {
//                e.printStackTrace();
//                response = "Error: " + e.getMessage();
//            }
//            return response;
//        }
//
//        @Override
//        protected void onPostExecute(String result) {
//            // Handle server response
//            // Update UI based on the response
//            // For example, display a message indicating login success/failure
//            if (result.equals("Login successful")) {
//                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
//                // Proceed to the next screen/activity
//                // Proceed to the next screen/activity
//                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
//                startActivity(intent);
//                finish();
//            } else {
//                Toast.makeText(LoginActivity.this, "Login failed", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
}